import sqlite3
con = sqlite3.connect("employeee.db")  
print("Database opened successfully")  
  
con.execute("create table Employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, roll TEXT UNIQUE NOT NULL, email TEXT NOT NULL, marks_short TEXT NOT NULL, marks_des TEXT NOT NULL)")  
  
print("Table created successfully")  
  
con.close()