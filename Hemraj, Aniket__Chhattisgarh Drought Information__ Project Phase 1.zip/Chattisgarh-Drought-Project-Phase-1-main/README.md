# Chattisgarh-Drought-Project-Phase-1
<h2>About</h2>
<p>This Project is intended to provide the Climatological drought information of different intensities in different districts of Chhattisgarh state, India (Data base: 1901-2020).
This project is designed by Hemraj Prajapati,and Aniket Vishwakarma. To visit <a href="https://hemraj-00.github.io/Chattisgarh-Drought-Project-Phase-1/"><b>Click Here</b></a>
