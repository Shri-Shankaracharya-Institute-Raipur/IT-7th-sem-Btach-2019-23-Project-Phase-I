# Complaint Management

## Environmrnt Setup
- Install [nodeJs](https://nodejs.org/en/)

## Backend

- open cmd with backend folder path
- Run command `npm install` (It will install all the required libraries and will take some time, wait to complete the installation)
- Run command `npm start` (Server will start)

## Frontend

- open cmd with frontend folder path
- Run command `npm install` (It will install all the required libraries and will take some time, wait to complete the installation)
- Run command `npm start` (Application will start and will open in the browser)
