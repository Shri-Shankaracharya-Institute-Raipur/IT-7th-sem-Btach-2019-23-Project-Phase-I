# stock_prediction_app
 College minor project - stock prediction using machine learning
[Take me to the webapp](https://stock-prediction-byvishal.streamlit.app/)

## QR Code for the webapp

![frame](https://user-images.githubusercontent.com/106560207/210089642-1a4c47fc-43ee-49db-9548-52895377fbc3.png)
