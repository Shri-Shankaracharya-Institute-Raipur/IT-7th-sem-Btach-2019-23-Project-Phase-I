from sklearn.preprocessing import MinMaxScaler
from statistics import mode
from matplotlib import figure
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pandas_datareader as data
from datetime import date
from keras.models import load_model
import streamlit as st
import plotly.figure_factory as ff
from plotly import graph_objs as go
from prophet import Prophet
from prophet.plot import plot_plotly

# add css file

with open('style.css') as f:
    st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)


stocks = ('TITAN','ASIANPAINT','HDFCBANK','ULTRACEMCO','WIPRO', 'VEDL', 'UPL', 'TECHM', 
          'TCS', 'TATASTEEL', 'TATAMOTORS', 'SUNPHARMA', 'SHREECEM', 'SBIN', 
          'RELIANCE', 'POWERGRID', 'ONGC', 'NTPC', 'NESTLEIND', 'MARUTI'
         , 'LT', 'KOTAKBANK', 'JSWSTEEL', 'ITC', 'IOC', 'INFY', 'INFRATEL', 'INDUSINDBK'
         , 'ICICIBANK', 'HINDUNILVR', 'HINDALCO', 'HEROMOTOCO', 'HDFC', 
          'HCLTECH', 'GRASIM', 'GAIL', 'EICHERMOT', 'DRREDDY', 'COALINDIA', 'CIPLA', 'BRITANNIA'
         , 'BPCL', 'BHARTIARTL', 'BAJAJFINSV', 'BAJFINANCE', 'BAJAJ-AUTO', 'AXISBANK',  'ADANIPORTS')
         
user_input = st.selectbox('Select dataset for prediction', stocks)

df = pd.read_csv(r'stock_data/{}.csv'.format(user_input))

df_p = df.drop(['Symbol'], axis=1)
df_p = df_p.drop(['Series'], axis=1)
df_p = df_p.drop(['Prev Close'], axis=1)
df_p = df_p.drop(['Last'], axis=1)
df_p = df_p.drop(['VWAP'], axis=1)
df_p = df_p.drop(['Volume'], axis=1)
df_p = df_p.drop(['Turnover'], axis=1)
df_p = df_p.drop(['Trades'], axis=1)
df_p = df_p.drop(['%Deliverble'], axis=1)
df_p = df_p.drop(['Deliverable Volume'], axis=1)
print(df_p)

n_years = st.slider('Years of prediction:', 1, 4)
period = n_years * 365

# Describing the data

st.write("##")

TODAY = date.today().strftime("%Y-%m-%d")


st.write("##")

st.subheader(f'Overview of data from 2008-01-01 to {TODAY}(Today)')
st.write(df.describe())


df_train = df_p[['Date', 'Close']]
df_train = df_train.rename(columns={"Date": "ds", "Close": "y"})
print(df_train)

# plotting the Graph

st.subheader('Graph of the stock (With 100 MA and 200 MA)')
ma100 = df.Close.rolling(100).mean()
ma200 = df.Close.rolling(200).mean()
fig = plt.figure(figsize=(12, 8))
plt.plot(df.Close)
plt.plot(ma100, 'g', label='100 MA')
plt.plot(ma200, 'r', label='200 MA')
# plt.show(fig)
st.pyplot(fig)

# splitting data in to traing and testing

data_training = pd.DataFrame(df['Close'][0:int(len(df)*0.8)])
data_testing = pd.DataFrame(df['Close'][int(len(df)*0.8): int(len(df))])

print(data_training.shape)
print(data_testing.shape)

scaler = MinMaxScaler(feature_range=(0, 1))
data_training_array = scaler.fit_transform(data_training)


# load my model
model = load_model('stock_prediction_keras.h5')

# Testing
past_100_days = data_training.tail(100)
final_df = past_100_days.append(data_testing, ignore_index=True)
input_data = scaler.fit_transform(final_df)
x_test = []
y_test = []

for i in range(100, input_data.shape[0]):
    x_test.append(input_data[i-100: i])
    y_test.append(input_data[i, 0])

x_test, y_test = np.array(x_test), np.array(y_test)

# making Predictions
y_predicted = model.predict(x_test)

scaler = scaler.scale_
scaler_factor = 1/scaler[0]
y_predicted = y_predicted*scaler_factor
y_test = y_test*scaler_factor

# Plotting Predictions on testing data
st.write("##")

st.subheader('Prediction on testing data')
fig2 = plt.figure(figsize=(12, 6))
plt.plot(y_test, 'b', label='Original Price')
plt.plot(y_predicted, 'r', label='Predicted')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
# plt.show(fig2)
st.pyplot(fig2)

 
# Show and plot forecast
m = Prophet(daily_seasonality=True)
m.fit(df_train)
future = m.make_future_dataframe(periods=period)
forecast = m.predict(future)

st.write("##")

st.header(f'Forecast plot for {n_years} years')
fig1 = plot_plotly(m, forecast, uncertainty=True, xlabel="Date", ylabel="Price")
# fig1.show()
st.plotly_chart(fig1)



# footer
st.write("##")
st.subheader('Made by - Vishal Agrawal and Abhay Mishra')
